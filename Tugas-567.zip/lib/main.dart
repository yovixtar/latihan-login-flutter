import 'package:flutter/material.dart';
import 'login.dart';
import 'model/user.dart';
import 'pages/dosen.dart';
import 'pages/mahasiswa.dart';
import 'pages/orangtua.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tugas 567',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Tugas 567'),
      routes: <String, WidgetBuilder>{
        '/login': (BuildContext context) => Login(),
        '/dosen': (BuildContext context) => Dosen(),
        '/mahasiswa': (BuildContext context) => Mahasiswa(),
        '/orangtua': (BuildContext context) => Orangtua()
      },
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Login(),
    );
  }
}
