class User {
  String? username, password, bagian;

  User({this.username, this.password, this.bagian});

  factory User.fromJson(Map<String, dynamic> json) => User(
        username: json['username'],
        password: json['password'],
        bagian: json['bagian'],
      );
  Map<String, dynamic> toJson() => {
        'username': username,
        'password': password,
        'bagian': bagian,
      };
}
