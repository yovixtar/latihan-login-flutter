package com.ibnu.tugas567

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
