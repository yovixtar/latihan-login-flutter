import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'model/user.dart';

class Login extends StatefulWidget {
  Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  String username = "", password = "";
  String pesanLogin = "";
  List _user = [];

  void cekAkun(String username, String password) async {
    final hasil = await http.post(
      Uri.parse("https://project.kuliah.iyabos.com/1/t567ih/login.php"),
      body: {
        'username': username,
        'password': password,
      },
    );
    // print(hasil.body['user'][index]['bagian']);
    Map<String, dynamic> map = json.decode(hasil.body);
    List<dynamic> data = map["user"];
    // print(map["user"]);
    if (map['user'].isEmpty == true) {
      print("Tidak Ada Data");
      setState(() {
        pesanLogin = "Gagal Login, pastikan Username dan Password benar";
      });
    } else {
      print(data[0]);
      Navigator.of(context).pushNamedAndRemoveUntil("/${data[0]['bagian']}", (Route<dynamic> route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Halaman Login",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Container(
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 0.0),
                child: Text(
                  "Login - 20.240.0137",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                  ),
                ),
              ),
              Visibility(
                visible: (pesanLogin == "" ? false : true),
                child: Container(
                  padding: EdgeInsets.all(10),
                  color: Color.fromARGB(255, 241, 237, 237),
                  child: Text(
                    pesanLogin,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20.0,
                      color: Colors.red,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              TextFormField(
                controller: usernameController,
                decoration: InputDecoration(
                  hintText: 'username',
                  border: UnderlineInputBorder(),
                  filled: true,
                  prefixIcon: Icon(Icons.person),
                  labelText: 'Username *',
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              TextFormField(
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'password',
                  border: UnderlineInputBorder(),
                  filled: true,
                  prefixIcon: Icon(Icons.lock),
                  labelText: 'Password *',
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(
                height: 24.0,
              ),
              MaterialButton(
                child: Text(
                  "Login",
                  style: TextStyle(
                    fontSize: 19,
                  ),
                ),
                height: 55.0,
                minWidth: 200.0,
                color: Colors.blue,
                textColor: Colors.white,
                onPressed: () => cekAkun(usernameController.text, passwordController.text),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
